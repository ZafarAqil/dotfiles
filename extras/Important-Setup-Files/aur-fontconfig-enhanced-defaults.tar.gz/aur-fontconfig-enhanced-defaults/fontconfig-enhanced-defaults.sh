export FT2_SUBPIXEL_HINTING=1
export _JAVA_OPTIONS="-Dawt.useSystemAAFontSettings=gasp $_JAVA_OPTIONS"
